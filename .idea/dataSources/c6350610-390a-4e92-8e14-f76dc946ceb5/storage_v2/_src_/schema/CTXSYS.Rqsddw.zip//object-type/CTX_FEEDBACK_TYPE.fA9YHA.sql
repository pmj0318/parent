create TYPE ctx_feedback_type AS TABLE OF ctx_feedback_item_type
/

