create type          SYS_PLSQL_55689_125_1 as table of CTXSYS."SYS_PLSQL_55689_100_1";
/

