create view DRV$UNINDEXED2 as
select "UNX_IDX_ID","UNX_IXP_ID","UNX_ROWID" from dr$unindexed
where unx_idx_id = SYS_CONTEXT('DR$APPCTX','IDXID')
with check option
/

