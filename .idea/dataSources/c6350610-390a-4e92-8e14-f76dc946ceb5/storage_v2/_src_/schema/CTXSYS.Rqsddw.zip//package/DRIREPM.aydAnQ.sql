create package drirepm as

/*--------------------------- describe_index --------------------------------*/

procedure describe_index(
  index_name    in varchar2,
  report        in out nocopy clob,
  report_format in varchar2 DEFAULT 'TEXT'
);

/*--------------------------- describe_policy -------------------------------*/

procedure describe_policy(
  policy_name   in varchar2,
  report        in out nocopy clob,
  report_format in varchar2 DEFAULT 'TEXT'
);

/*-------------------------- create_index_script ----------------------------*/

procedure create_index_script(
  index_name      in varchar2,
  report          in out nocopy clob,
  prefname_prefix in varchar2 default null
);

/*-------------------------- create_policy_script ---------------------------*/

procedure create_policy_script(
  policy_name      in varchar2,
  report          in out nocopy clob,
  prefname_prefix in varchar2 default null
);

end drirepm;
/

