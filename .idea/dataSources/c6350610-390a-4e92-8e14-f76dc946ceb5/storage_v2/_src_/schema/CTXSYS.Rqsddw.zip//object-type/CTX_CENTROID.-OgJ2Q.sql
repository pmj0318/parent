create type ctx_centroid as object (
  attribute_name varchar2(30),
  mean           number,
  mode_value     varchar2(4000),
  variance       number
);
/

