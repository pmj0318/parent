create type          SYS_PLSQL_55689_66_1 as table of CTXSYS."SYS_PLSQL_55689_38_1";
/

