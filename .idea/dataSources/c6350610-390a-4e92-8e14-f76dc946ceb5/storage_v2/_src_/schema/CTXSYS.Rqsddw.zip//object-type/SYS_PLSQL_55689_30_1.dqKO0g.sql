create type          SYS_PLSQL_55689_30_1 as table of CTXSYS."SYS_PLSQL_55689_12_1";
/

