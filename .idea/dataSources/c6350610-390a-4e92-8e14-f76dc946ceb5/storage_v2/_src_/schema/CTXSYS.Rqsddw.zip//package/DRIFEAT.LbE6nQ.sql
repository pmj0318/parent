create PACKAGE drifeat AUTHID CURRENT_USER AS
  FUNCTION dr$opr_track (track_info IN OUT NOCOPY CLOB)  RETURN INTEGER;
  FUNCTION dr$idx_track (track_info IN OUT NOCOPY CLOB)  RETURN INTEGER;
  FUNCTION dr$pac_track (track_info IN OUT NOCOPY CLOB)  RETURN INTEGER;
  PROCEDURE dr$feature_track
      (is_used OUT number, aux_count OUT number, sum_stat OUT clob);
END drifeat;
/

