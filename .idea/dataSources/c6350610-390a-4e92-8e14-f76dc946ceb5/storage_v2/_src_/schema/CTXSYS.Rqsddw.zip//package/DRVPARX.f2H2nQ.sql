create package drvparx authid current_user is
   FUNCTION ParallelPopuIndex(
     cur        SYS_REFCURSOR,
     idxownid   number,
     idxid      number,
     idxo       varchar2,
     idxn       varchar2,
     idxp       varchar2,
     idxpopstate dr$popindex_state_t)
       return sys.odcivarchar2list
      parallel_enable(partition cur by any) pipelined;

   FUNCTION IndexOptimizeParFn(
     crsr        in drvddl.popcurtyp,
     idxownid    in number,
     idxowner    in varchar2,
     idxname     in varchar2,
     ixpname     in varchar2,
     shadow_itab in varchar2,
     nextid     in number,
     shadow_ntab in varchar2,
     optstate    in dr$optim_state_t
   ) return sys.odcivarchar2list
     pipelined parallel_enable (partition crsr BY HASH(num));

   FUNCTION TraceGetTrace return dr$trc_tab;

end drvparx;
/

