create type          SYS_PLSQL_55689_DUMMY_1 as table of number;
/

