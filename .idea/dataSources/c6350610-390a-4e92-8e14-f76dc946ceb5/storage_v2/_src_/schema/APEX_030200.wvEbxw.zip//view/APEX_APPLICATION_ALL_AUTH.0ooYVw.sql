create view APEX_APPLICATION_ALL_AUTH as
  select workspace, application_id, application_name, null page_id, 'Application'            component_type, application_name                component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATIONS                where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'Breadcrumb Entry'       component_type, ENTRY_LABEL                     component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_BC_ENTRIES      where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'Application Compuation' component_type, COMPUTATION_ITEM                component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_COMPUTATIONS    where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'List Entry'             component_type, ENTRY_TEXT                      component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_LIST_ENTRIES    where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'Navigation Bar'         component_type, ICON_SUBTEXT                    component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_NAV_BAR         where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page'                   component_type, page_name                       component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGES           where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Branch'            component_type, substr(BRANCH_ACTION,1,30)      component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_BRANCHES   where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Button'            component_type, BUTTON_NAME                     component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_BUTTONS    where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Computation'       component_type, ITEM_NAME                       component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_COMP       where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Item'              component_type, item_name                       component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_ITEMS      where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Process'           component_type, process_name                    component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_PROC       where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Region'            component_type, region_name                     component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_REGIONS    where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Report Column'     component_type, region_name||'. '||column_alias component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_RPT_COLS   where authorization_scheme is not null
union all select workspace, application_id, application_name, page_id,      'Page Validation'        component_type, VALIDATION_NAME                 component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PAGE_VAL        where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'Parent Tab'             component_type, tab_name                        component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PARENT_TABS     where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'Application Process'    component_type, process_name                    component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_PROCESSES       where authorization_scheme is not null
union all select workspace, application_id, application_name, null page_id, 'Tab'                    component_type, tab_name                        component_name, authorization_scheme, decode(replace(translate(authorization_scheme,'1234567890!','00000000000'),'0',null),null,'Invalid','Valid') status  from APEX_APPLICATION_TABS            where authorization_scheme is not null
/

comment on table APEX_APPLICATION_ALL_AUTH is 'All authorization schemes for all components by Application'
/

comment on column APEX_APPLICATION_ALL_AUTH.WORKSPACE is 'Authorization Scheme Workspace'
/

comment on column APEX_APPLICATION_ALL_AUTH.APPLICATION_ID is 'Authorization Scheme Application ID'
/

comment on column APEX_APPLICATION_ALL_AUTH.APPLICATION_NAME is 'Authorization Scheme Application Name'
/

comment on column APEX_APPLICATION_ALL_AUTH.PAGE_ID is 'Authorization Scheme Page ID'
/

comment on column APEX_APPLICATION_ALL_AUTH.COMPONENT_TYPE is 'Authorization Scheme Apex component type'
/

comment on column APEX_APPLICATION_ALL_AUTH.COMPONENT_NAME is 'Authorization Scheme Apex component name'
/

comment on column APEX_APPLICATION_ALL_AUTH.AUTHORIZATION_SCHEME is 'Authorization Scheme name'
/

comment on column APEX_APPLICATION_ALL_AUTH.STATUS is 'Authorization Scheme status'
/

