create view APEX_APPLICATION_TREES as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.TREE_NAME                      tree_name,
    t.TREE_TYPE                      tree_type,
    t.TREE_QUERY                     tree_query,
    t.FLOW_ITEM                      ,
    t.MAX_LEVELS                     maximum_levels,
    t.UNEXPANDED_PARENT              ,
    t.UNEXPANDED_PARENT_LAST         ,
    t.EXPANDED_PARENT                ,
    t.EXPANDED_PARENT_LAST           ,
    t.LEAF_NODE                      ,
    t.LEAF_NODE_LAST                 ,
    t.DRILL_UP                       ,
    t.NAME_LINK_ANCHOR_TAG           ,
    t.NAME_LINK_NOT_ANCHOR_TAG       ,
    t.INDENT_VERTICAL_LINE           ,
    t.INDENT_VERTICAL_LINE_LAST      ,
    t.BEFORE_TREE                    ,
    t.AFTER_TREE                     ,
    t.LEVEL_1_TEMPLATE               ,
    t.LEVEL_2_TEMPLATE               ,
    t.LEVEL_3_TEMPLATE               ,
    t.LEVEL_4_TEMPLATE               ,
    t.LEVEL_5_TEMPLATE               ,
    t.LEVEL_6_TEMPLATE               ,
    t.LEVEL_7_TEMPLATE               ,
    t.LEVEL_8_TEMPLATE               ,
    --
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    --
    t.TREE_COMMENT                   component_comment,
    t.id                             application_tree_id,
    --
    t.TREE_NAME
    ||' t='||t.TREE_TYPE
    ||substr(t.TREE_QUERY,1,50)||length(t.tree_query)
    ||' i='||t.FLOW_ITEM
    ||' l='||t.MAX_LEVELS
    ||'.'||length(t.UNEXPANDED_PARENT        )
    ||'.'||length(t.UNEXPANDED_PARENT_LAST   )
    ||'.'||length(t.EXPANDED_PARENT          )
    ||'.'||length(t.EXPANDED_PARENT_LAST     )
    ||'.'||length(t.LEAF_NODE                )
    ||'.'||length(t.LEAF_NODE_LAST           )
    ||'.'||length(t.DRILL_UP                 )
    ||'.'||length(t.NAME_LINK_ANCHOR_TAG     )
    ||'.'||length(t.NAME_LINK_NOT_ANCHOR_TAG )
    ||'.'||length(t.INDENT_VERTICAL_LINE     )
    ||'.'||length(t.INDENT_VERTICAL_LINE_LAST)
    ||'.'||length(t.BEFORE_TREE              )
    ||'.'||length(t.AFTER_TREE               )
    ||'.'||length(t.LEVEL_1_TEMPLATE         )
    ||'.'||length(t.LEVEL_2_TEMPLATE         )
    ||'.'||length(t.LEVEL_3_TEMPLATE         )
    ||'.'||length(t.LEVEL_4_TEMPLATE         )
    ||'.'||length(t.LEVEL_5_TEMPLATE         )
    ||'.'||length(t.LEVEL_6_TEMPLATE         )
    ||'.'||length(t.LEVEL_7_TEMPLATE         )
    ||'.'||length(t.LEVEL_8_TEMPLATE         )
    component_signature
from wwv_flow_trees t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_TREES is 'Identifies a tree control which can be referenced and displayed by creating a region with a source of this tree'
/

comment on column APEX_APPLICATION_TREES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TREES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TREES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TREES.TREE_NAME is 'Component name'
/

comment on column APEX_APPLICATION_TREES.TREE_TYPE is 'Tree component type'
/

comment on column APEX_APPLICATION_TREES.TREE_QUERY is 'Query which will be used to generate this tree'
/

comment on column APEX_APPLICATION_TREES.FLOW_ITEM is 'Identifies an application or page item which specifies the starting point of the tree'
/

comment on column APEX_APPLICATION_TREES.MAXIMUM_LEVELS is 'This attribute specifies how many levels will appear when a tree first displays'
/

comment on column APEX_APPLICATION_TREES.UNEXPANDED_PARENT is 'HTML template for unexpanded parent nodes'
/

comment on column APEX_APPLICATION_TREES.UNEXPANDED_PARENT_LAST is 'HTML template for the last unexpanded parent node'
/

comment on column APEX_APPLICATION_TREES.EXPANDED_PARENT is 'HTML template for the expanded parent node'
/

comment on column APEX_APPLICATION_TREES.EXPANDED_PARENT_LAST is 'HTML template for the last expanded parent node'
/

comment on column APEX_APPLICATION_TREES.LEAF_NODE is 'Controls the text that is painted before showing the text of the leaf node'
/

comment on column APEX_APPLICATION_TREES.LEAF_NODE_LAST is 'Controls the text that is painted before showing the text of the last leaf node.'
/

comment on column APEX_APPLICATION_TREES.DRILL_UP is 'Identifies the link text shown when drilling up is possible in the tree'
/

comment on column APEX_APPLICATION_TREES.NAME_LINK_ANCHOR_TAG is 'Identifies the manner in which a Name will render if the name has a link'
/

comment on column APEX_APPLICATION_TREES.NAME_LINK_NOT_ANCHOR_TAG is 'Tag for node names which are not links'
/

comment on column APEX_APPLICATION_TREES.INDENT_VERTICAL_LINE is 'Controls vertical line or spacing between peers'
/

comment on column APEX_APPLICATION_TREES.INDENT_VERTICAL_LINE_LAST is 'Indent Vertical Line Last, controls a blank space'
/

comment on column APEX_APPLICATION_TREES.BEFORE_TREE is 'Text before displaying any nodes of the tree'
/

comment on column APEX_APPLICATION_TREES.AFTER_TREE is 'Text after displaying nodes of the tree'
/

comment on column APEX_APPLICATION_TREES.LEVEL_1_TEMPLATE is 'Parent Node Template'
/

comment on column APEX_APPLICATION_TREES.LEVEL_2_TEMPLATE is 'Node Text Template'
/

comment on column APEX_APPLICATION_TREES.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_TREES.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TREES.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TREES.APPLICATION_TREE_ID is 'Primary Key of this Application Tree shared component'
/

comment on column APEX_APPLICATION_TREES.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

