create view APEX_APPLICATION_PAGE_IR_CGRPS as
select
w.short_name                workspace,
f.id                        application_id,
f.name                      application_name,
cg.worksheet_id             interactive_report_id,
cg.name                     column_group_name,
cg.description              column_group_description,
cg.display_sequence         display_sequence,
--
(select count(*) from wwv_flow_worksheet_columns where group_id = cg.id) columns,
--
cg.created_on                ,
cg.created_by                ,
cg.updated_on                ,
cg.updated_by
from wwv_flow_worksheet_col_groups cg,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = cg.security_group_id and
      f.id = ws.flow_id and ws.id = cg.worksheet_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_PAGE_IR_CGRPS is 'Column group definitions for interactive report columns'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.COLUMN_GROUP_NAME is 'Name of this column group, displayed on the single row view of this report and in the Select Columns dialog box'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.COLUMN_GROUP_DESCRIPTION is 'Description of this column group'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.DISPLAY_SEQUENCE is 'Display sequence of this column group'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.COLUMNS is 'Number of columns in this column group'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR_CGRPS.UPDATED_BY is 'Auditing; user that last modified the record.'
/

