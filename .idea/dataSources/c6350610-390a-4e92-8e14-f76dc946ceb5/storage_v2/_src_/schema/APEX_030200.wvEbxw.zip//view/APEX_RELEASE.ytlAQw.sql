create view APEX_RELEASE as
select (select wwv_flows_release from dual) version_no,
       (select wwv_flows_version from dual) api_compatibility,
       (select wwv_flow_platform.get_preference('APEX_3_0_1_PATCH') from dual) patch_applied
  from dual
/

comment on table APEX_RELEASE is 'Identifies this release of Application Express'
/

comment on column APEX_RELEASE.VERSION_NO is 'The specific version number of this Application Express instance'
/

comment on column APEX_RELEASE.API_COMPATIBILITY is 'The version of the API that this release is compatible with for importing applications or components'
/

comment on column APEX_RELEASE.PATCH_APPLIED is 'The date a patch was applied if this instance was patched'
/

