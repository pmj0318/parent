create trigger WWV_FLOW_PURGED_SESS_BIU
  before insert or update
  on WWV_FLOW_PURGED_SESSIONS$
  for each row
begin
    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
end;
/

