create trigger WWV_BIU_WWV_FLOW_HNT_PROCEDURE
  before insert or update
  on WWV_FLOW_HNT_PROCEDURE_INFO
  for each row
begin
    if :new.procedure_id is null then
        :new.procedure_id := wwv_flow_id.next_val;
    end if;

    if inserting then
        :new.created_by := nvl(wwv_flow.g_user,user);
        :new.created_on := sysdate;
    elsif updating then
        :new.last_updated_by := nvl(wwv_flow.g_user,user);
        :new.last_updated_on := sysdate;
    end if;
end;
/

