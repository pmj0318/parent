create view APEX_APPLICATION_TEMP_LABEL as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.THEME_ID                       theme_number,
    decode(t.THEME_CLASS_ID,
      '1','Optional Label with Help',
      '2','Required Label with Help',
      '3','Optional Label',
      '4','Required Label',
      '5','Custom 1',
      '6','Custom 2',
      '7','Custom 3',
      '8','Custom 4',
      '9','Custom 5',
      '10','Custom 6',
      '11','Custom 7',
      '12','Custom 8',
      '13','No Label',
      t.THEME_CLASS_ID)              theme_class,
    --
    t.TEMPLATE_NAME                  template_name,
    t.TEMPLATE_BODY1                 before_label,
    t.TEMPLATE_BODY2                 after_label,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from WWV_FLOW_FIELD_TEMPLATES
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    t.ON_ERROR_BEFORE_LABEL,
    t.ON_ERROR_AFTER_LABEL,
    t.LAST_UPDATED_ON                last_updated_on,
    t.LAST_UPDATED_BY                last_updated_by,
    t.TRANSLATE_THIS_TEMPLATE        ,
    t.TEMPLATE_COMMENT               component_comment,
    t.id                             label_template_id,
    --
    t.TEMPLATE_NAME
    ||' t='||t.THEME_ID
    ||' c='||t.THEME_CLASS_ID
    ||' 1='||substr(t.TEMPLATE_BODY1,1,40)||length(t.TEMPLATE_BODY1)
    ||' 2='||substr(t.TEMPLATE_BODY2,1,40)||length(t.TEMPLATE_BODY2)
    ||' r='||decode(t.REFERENCE_ID,null,'N','Y')
    ||' e='||substr(t.ON_ERROR_BEFORE_LABEL,1,40)||length(t.ON_ERROR_BEFORE_LABEL)
    ||' e='||substr(t.ON_ERROR_AFTER_LABEL,1,40)||length(t.ON_ERROR_AFTER_LABEL)
    ||' t='||t.TRANSLATE_THIS_TEMPLATE
    component_signature
from WWV_FLOW_FIELD_TEMPLATES t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_TEMP_LABEL is 'Identifies a Page Item Label HTML template display attributes'
/

comment on column APEX_APPLICATION_TEMP_LABEL.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TEMP_LABEL.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TEMP_LABEL.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TEMP_LABEL.THEME_NUMBER is 'Identifies the theme number associated with all templates within the theme'
/

comment on column APEX_APPLICATION_TEMP_LABEL.THEME_CLASS is 'Identifies a specific usage for this template'
/

comment on column APEX_APPLICATION_TEMP_LABEL.TEMPLATE_NAME is 'Identifies the name of this Item Label Template'
/

comment on column APEX_APPLICATION_TEMP_LABEL.BEFORE_LABEL is 'HTML to be displayed before an item label'
/

comment on column APEX_APPLICATION_TEMP_LABEL.AFTER_LABEL is 'HTML to be displayed after an item label'
/

comment on column APEX_APPLICATION_TEMP_LABEL.IS_SUBSCRIBED is 'Identifies if this Item Label Template is subscribed from another Item Label Template'
/

comment on column APEX_APPLICATION_TEMP_LABEL.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPLICATION_TEMP_LABEL.ON_ERROR_BEFORE_LABEL is 'HTML to precede the item label when a application displays an inline validation error message for the item'
/

comment on column APEX_APPLICATION_TEMP_LABEL.ON_ERROR_AFTER_LABEL is 'HTML to be appended to the item label when a application  displays an inline validation error message for the item'
/

comment on column APEX_APPLICATION_TEMP_LABEL.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TEMP_LABEL.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_TEMP_LABEL.TRANSLATE_THIS_TEMPLATE is 'Identifies if this template should be translated'
/

comment on column APEX_APPLICATION_TEMP_LABEL.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TEMP_LABEL.LABEL_TEMPLATE_ID is 'Primary Key of this Item Label Template'
/

comment on column APEX_APPLICATION_TEMP_LABEL.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

