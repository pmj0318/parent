create view OC_ORDERS as
SELECT o.order_id, o.order_mode,MAKE_REF(oc_customers,o.customer_id),
        o.order_status,o.order_total,o.sales_rep_id,
       CAST(MULTISET(SELECT l.order_id,l.line_item_id,l.unit_price,l.quantity,
                       make_ref(oc_product_information,l.product_id)
                     FROM order_items l
                     WHERE o.order_id = l.order_id)
            AS order_item_list_typ)
    FROM orders o
/

create trigger ORDERS_TRG
  instead of insert
  on OC_ORDERS
  for each row
-- missing source code
/

create trigger ORDERS_ITEMS_TRG
  instead of insert
  on OC_ORDERS
  for each row
-- missing source code
/

