create trigger "PURCHASEORDER$xd"
  after update or delete
  on PURCHASEORDER
  for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('OE','PURCHASEORDER', :old.sys_nc_oid$, 'C64C072E0EC64B47B84AAF9B098FF919' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('OE','PURCHASEORDER', :old.sys_nc_oid$, 'C64C072E0EC64B47B84AAF9B098FF919', user ); END IF; END;
/

