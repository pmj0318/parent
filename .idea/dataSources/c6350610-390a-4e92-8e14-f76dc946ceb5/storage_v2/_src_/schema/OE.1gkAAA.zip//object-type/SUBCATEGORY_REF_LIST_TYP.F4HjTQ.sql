create TYPE subcategory_ref_list_typ
                                         AS TABLE OF REF category_typ;
/

