create type      "SYS_YOID0000074527$" as object( "SYS_NC00001$" NUMBER(12,0))
/

