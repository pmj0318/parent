create TYPE product_ref_list_typ
                                         AS TABLE OF number(6);
/

