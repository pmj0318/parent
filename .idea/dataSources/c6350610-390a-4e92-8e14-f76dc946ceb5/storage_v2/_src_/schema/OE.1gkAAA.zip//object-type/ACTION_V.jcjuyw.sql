create TYPE      "ACTION_V" AS VARRAY(4) OF "ACTION_T"
/

