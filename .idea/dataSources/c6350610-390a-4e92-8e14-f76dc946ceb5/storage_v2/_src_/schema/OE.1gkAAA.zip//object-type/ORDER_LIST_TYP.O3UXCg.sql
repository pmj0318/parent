create TYPE order_list_typ
                                         AS TABLE OF order_typ;
/

