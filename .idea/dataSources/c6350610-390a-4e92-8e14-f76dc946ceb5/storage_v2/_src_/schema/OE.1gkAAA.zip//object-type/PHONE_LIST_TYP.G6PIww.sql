create TYPE "PHONE_LIST_TYP"                                                                                                                     AS VARRAY(5) OF VARCHAR2(25);
/

