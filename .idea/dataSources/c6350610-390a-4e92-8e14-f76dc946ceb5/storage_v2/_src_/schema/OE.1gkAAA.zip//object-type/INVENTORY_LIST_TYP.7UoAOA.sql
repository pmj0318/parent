create TYPE inventory_list_typ
                                         AS TABLE OF inventory_typ;
/

