create TYPE category_typ
                                         AS OBJECT
    ( category_name           VARCHAR2(50)
    , category_description    VARCHAR2(1000)
    , category_id             NUMBER(2)
    , NOT instantiable
      MEMBER FUNCTION category_describe RETURN VARCHAR2
      )
  NOT INSTANTIABLE NOT FINAL
 ALTER TYPE category_typ
 ADD ATTRIBUTE (parent_category_id number(2)) CASCADE
/

