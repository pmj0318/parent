create view ACCOUNT_MANAGERS as
SELECT          c.account_mgr_id                ACCT_MGR,
                cr.region_id                    REGION,
                c.cust_address.country_id       COUNTRY,
                c.cust_address.state_province   PROVINCE,
                count(*)                        NUM_CUSTOMERS
FROM            customers c, countries cr
WHERE           c.cust_address.country_id = cr.country_id
GROUP BY ROLLUP (c.account_mgr_id,
                 cr.region_id,
                 c.cust_address.country_id,
                 c.cust_address.state_province)
/

