create TYPE corporate_customer_typ
                                         UNDER customer_typ
      ( account_mgr_id     NUMBER(6)
      );
/

