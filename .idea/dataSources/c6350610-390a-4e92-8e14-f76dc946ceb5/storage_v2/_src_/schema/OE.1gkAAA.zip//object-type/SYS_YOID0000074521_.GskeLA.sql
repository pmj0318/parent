create type      "SYS_YOID0000074521$" as object( "SYS_NC00001$" NUMBER(6,0))
/

