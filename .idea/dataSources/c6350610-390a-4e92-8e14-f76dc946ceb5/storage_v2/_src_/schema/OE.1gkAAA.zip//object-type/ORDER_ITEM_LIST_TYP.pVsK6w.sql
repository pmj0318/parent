create TYPE order_item_list_typ
                                         AS TABLE OF order_item_typ;
/

