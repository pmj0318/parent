create type      "SYS_YOID0000074525$" as object( "SYS_NC00001$" NUMBER(6,0))
/

