create view ALL_RLMGR_RULE_CLASS_OPCODES as
select rset_stcode, rset_stdesc, rset_stnext from rlm$rulesetstcode
/

