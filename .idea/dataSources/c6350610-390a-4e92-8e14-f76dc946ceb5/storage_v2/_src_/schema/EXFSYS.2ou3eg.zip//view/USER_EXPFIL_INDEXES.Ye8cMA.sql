create view USER_EXPFIL_INDEXES as
select io.idxname, io.idxpredtab, io.idxaccfunc, io.idxattrset,
         io.idxesettab, idxesetcol, io.idxstatus, io.optfccpuct,
         io.optfcioct, io.optixselvt, io.optixcpuct, io.optixioct
  from exf$idxsecobj io
  where io.idxowner = (select user from dual)
/

comment on table USER_EXPFIL_INDEXES is 'List of all the expression filter indexes in this schema'
/

comment on column USER_EXPFIL_INDEXES.INDEX_NAME is 'Name of the index'
/

comment on column USER_EXPFIL_INDEXES.PREDICATE_TABLE is 'Predicate table associated with the index'
/

comment on column USER_EXPFIL_INDEXES.ACCESS_FUNC_PACKAGE is 'System generated package that implements the index''s access function'
/

comment on column USER_EXPFIL_INDEXES.ATTRIBUTE_SET is 'Name of the attribute set used for this index'
/

comment on column USER_EXPFIL_INDEXES.EXPRESSION_TABLE is 'The table storing the expression set corresponding to this index'
/

comment on column USER_EXPFIL_INDEXES.EXPRESSION_COLUMN is 'The column storing the expression set corresponding to this index'
/

comment on column USER_EXPFIL_INDEXES.STATUS is 'The current status of the index : VALID, FAILED [IMP], INPROGRESS'
/

comment on column USER_EXPFIL_INDEXES.FUNC_CPU_COST is 'Estimated CPU cost for function based evaluation of each expression'
/

comment on column USER_EXPFIL_INDEXES.FUNC_IO_COST is 'Estimated I/O cost for function based evaluation of each expression'
/

comment on column USER_EXPFIL_INDEXES.INDEX_SELECTIVITY is 'Estimated selectivity of the index'
/

comment on column USER_EXPFIL_INDEXES.INDEX_CPU_COST is 'Estimated CPU cost for the index based evaluation of expressions'
/

comment on column USER_EXPFIL_INDEXES.INDEX_IO_COST is 'Estimated I/O cost for the index based evaluation of expressions'
/

