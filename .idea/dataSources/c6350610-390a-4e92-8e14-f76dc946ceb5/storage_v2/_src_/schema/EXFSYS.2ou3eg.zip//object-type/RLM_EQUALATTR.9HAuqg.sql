create type        rlm$equalattr as VARRAY(32) of VARCHAR2(32);
/

