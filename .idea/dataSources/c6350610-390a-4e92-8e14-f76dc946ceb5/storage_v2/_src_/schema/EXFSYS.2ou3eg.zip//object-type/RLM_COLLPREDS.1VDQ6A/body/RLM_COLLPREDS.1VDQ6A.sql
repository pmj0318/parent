create type body         rlm$collpreds as
  constructor function rlm$collpreds return self as result is
  begin
    null;
    return;
  end;
end;
/

