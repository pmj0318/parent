create view USER_RLMGR_ACTION_ERRORS as
select rset_name, actschat, oraerrcde from rlm$schacterrs
  where rset_owner = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

comment on table USER_RLMGR_ACTION_ERRORS is 'Table listing the errors encountered during action execution'
/

comment on column USER_RLMGR_ACTION_ERRORS.RULE_CLASS_NAME is 'Name of the rule class producing the errors during action execution'
/

comment on column USER_RLMGR_ACTION_ERRORS.SCHEDULED_TIME is 'Time at which the action was scheduled to run.'
/

comment on column USER_RLMGR_ACTION_ERRORS.ORA_ERROR is 'Code for the error encountered : ORA-XXXXX'
/

