create view ALL_EXPFIL_ASET_FUNCTIONS as
select udfasoner, udfasname, udfname, udfobjown, udfobjnm, udftype from
   exf$asudflist, all_types ao where
   udfasoner = ao.owner and udfasname = ao.type_name
/

comment on table ALL_EXPFIL_ASET_FUNCTIONS is 'List of approved user-defined functions for the attribute sets accessible
 to the user'
/

comment on column ALL_EXPFIL_ASET_FUNCTIONS.OWNER is 'Owner of the attribute set'
/

comment on column ALL_EXPFIL_ASET_FUNCTIONS.ATTRIBUTE_SET_NAME is 'Name of the attribute set'
/

comment on column ALL_EXPFIL_ASET_FUNCTIONS.UDF_NAME is 'Name of the user-defined FUNCTION/PACKAGE/TYPE'
/

comment on column ALL_EXPFIL_ASET_FUNCTIONS.OBJECT_OWNER is 'Owner of the object'
/

comment on column ALL_EXPFIL_ASET_FUNCTIONS.OBJECT_NAME is 'Name of the object'
/

comment on column ALL_EXPFIL_ASET_FUNCTIONS.OBJECT_TYPE is 'Type of the object - FUNCTION/PACKAGE/TYPE'
/

