create view ADM_RLMGR_EVENT_STRUCTS as
select evst_owner, evst_name,
         decode(bitand(evst_prop, 1), 1, 'YES','NO'),
         decode(bitand(evst_prop, 2), 2, 'YES','NO'),
         decode(bitand(evst_prop, 128), 128, 'YES','NO'),
         es.evst_prcttls, evst_prct
  from rlm$eventstruct es
/

