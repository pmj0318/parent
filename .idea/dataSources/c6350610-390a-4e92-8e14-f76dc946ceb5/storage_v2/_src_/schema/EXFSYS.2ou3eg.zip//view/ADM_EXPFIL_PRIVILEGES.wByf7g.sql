create view ADM_EXPFIL_PRIVILEGES as
select esowner, esexptab, esexpcol, esgrantee, escrtpriv, esupdpriv from
   exf$expsetprivs
/

comment on table ADM_EXPFIL_PRIVILEGES is 'Privileges for Expression set modifications'
/

comment on column ADM_EXPFIL_PRIVILEGES.EXPSET_OWNER is 'Owner of the table storing the expression set. Also the grantor'
/

comment on column ADM_EXPFIL_PRIVILEGES.EXPSET_TABLE is 'The table storing the expression set in the owner''s schema'
/

comment on column ADM_EXPFIL_PRIVILEGES.EXPSET_COLUMN is 'The column storing the expression set'
/

comment on column ADM_EXPFIL_PRIVILEGES.GRANTEE is 'Grantee of the privilege. PUBLIC implies any user'
/

