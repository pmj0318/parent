create package adm_expfil_systrig as

  /*************************************************************************/
  /*** CREATE_SYSTRIG_DROPOBJ : System trigger to manage meta-data after ***/
  /*** the drop of expression table and user with attributes sets. Also  ***/
  /*** restricts the user from dropping the ADT associated with an       ***/
  /*** Attribute set. Name of the trigger created : EXPFIL_DROPOBJ_MAINT ***/
  /*************************************************************************/
  procedure create_systrig_dropobj;

  /*************************************************************************/
  /*** CREATE_SYSTRIG_TRUNCRULCLS : Trigger to perform the necessary     ***/
  /*** maintenance for TRUNCATE of a rule class table                    ***/
  /*************************************************************************/
  procedure create_systrig_truncrulcls;

  /*************************************************************************/
  /*** CREATE_SYSTRIG_TYPEEVOLVE : System trigger to restrict ALTER and  ***/
  /*** CREATE or REPLACE operations on the ADT associated with an        ***/
  /*** Attribute set. Name of trig created : EXPFIL_RESTRICT_TYPEEVOLVE  ***/
  /*************************************************************************/
  procedure create_systrig_typeevolve;

  /*************************************************************************/
  /*** CREATE_SYSTRIG_ALTEREXPTAB : System trigger to manage meta-data   ***/
  /*** after a drop of expression column from the user table or a rename ***/
  /*** of the expression table. Name of trig : EXPFIL_ALTEREXPTAB_MAINT  ***/
  /*************************************************************************/
  procedure create_systrig_alterexptab;

  /*************************************************************************/
  /*** DISABLE_ALL : Api to disable all the system triggers in the EXPFIL***/
  /*** schema temporarily. They can be re-enabled using ENABLE_ALL API   ***/
  /*************************************************************************/
  procedure disable_all;

  /*************************************************************************/
  /*** ENABLE_ALL : Api to enable all the system triggers in the EXPFIL  ***/
  /*** schema. The triggers should exist in a valid state for this to    ***/
  /*** succeed. See CREATE_SYSTRIG_* APIs to create the triggers         ***/
  /*************************************************************************/
  procedure enable_all;

end;
/

