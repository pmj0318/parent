create view ALL_RLMGR_EVENT_STRUCTS as
select evst_owner, evst_name,
         decode(bitand(evst_prop, 1), 1, 'YES','NO'),
         decode(bitand(evst_prop, 2), 2, 'YES','NO'),
         es.evst_prcttls, es.evst_prct
  from rlm$eventstruct es,  all_types ao
   where ao.owner = es.evst_owner and ao.type_name = es.evst_name and
         bitand(es.evst_prop, 128) = 0
/

comment on table ALL_RLMGR_EVENT_STRUCTS is 'List of all the event structures in the current schema'
/

comment on column ALL_RLMGR_EVENT_STRUCTS.EVENT_STRUCTURE_OWNER is 'Owner of the event structure'
/

comment on column ALL_RLMGR_EVENT_STRUCTS.EVENT_STRUCTURE_NAME is 'Name of the event structure'
/

comment on column ALL_RLMGR_EVENT_STRUCTS.HAS_TIMESTAMP is 'Event structure has the event creation timestamp - YES/NO'
/

comment on column ALL_RLMGR_EVENT_STRUCTS.IS_PRIMITIVE is 'Event structure is strictly for primitive events - YES/NO'
/

comment on column ALL_RLMGR_EVENT_STRUCTS.TABLE_ALIAS_OF is 'Table name for a table alias primitive event'
/

comment on column ALL_RLMGR_EVENT_STRUCTS.CONDITIONS_TABLE is 'Name of the table that stores the sharable conditions for this event structure'
/

