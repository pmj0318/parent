create type        exf$indexoper as VARRAY(20) of VARCHAR2(15);
/

