create view USER_RLMGR_EVENT_STRUCTS as
select es.evst_name, decode(bitand(es.evst_prop, 1), 1, 'YES','NO'),
         decode(bitand(es.evst_prop, 2), 2, 'YES','NO'),
         es.evst_prcttls, es.evst_prct
  from rlm$eventstruct es
  where es.evst_owner = sys_context('USERENV', 'CURRENT_USER') and
        bitand(es.evst_prop, 128) = 0
/

comment on table USER_RLMGR_EVENT_STRUCTS is 'List of all the event structures in the current schema'
/

comment on column USER_RLMGR_EVENT_STRUCTS.EVENT_STRUCTURE_NAME is 'Name of the event structure'
/

comment on column USER_RLMGR_EVENT_STRUCTS.HAS_TIMESTAMP is 'Event structure has the event creation timestamp - YES/NO'
/

comment on column USER_RLMGR_EVENT_STRUCTS.IS_PRIMITIVE is 'Event structure is strictly for primitive events - YES/NO'
/

comment on column USER_RLMGR_EVENT_STRUCTS.TABLE_ALIAS_OF is 'Table name for a table alias primitive event'
/

comment on column USER_RLMGR_EVENT_STRUCTS.CONDITIONS_TABLE is 'Name of the table that stores the sharable conditions for this event structure'
/

