create type exf$xptagsinfo as VARRAY(490) of exf$xptaginfo;
/

