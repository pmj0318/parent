create view ADM_EXPFIL_INDEXES as
select io.idxowner, io.idxname, io.idxpredtab, io.idxaccfunc,
         io.idxattrset, io.idxesettab, idxesetcol, io.idxstatus
  from exf$idxsecobj io
/

comment on table ADM_EXPFIL_INDEXES is 'List of all the expression filter indexes in this instance'
/

comment on column ADM_EXPFIL_INDEXES.OWNER is 'Owner of the index'
/

comment on column ADM_EXPFIL_INDEXES.INDEX_NAME is 'Name of the index'
/

comment on column ADM_EXPFIL_INDEXES.PREDICATE_TABLE is 'Predicate table associated with the index'
/

comment on column ADM_EXPFIL_INDEXES.ACCESS_FUNC_PACKAGE is 'System generated package that implements the index''s access function'
/

comment on column ADM_EXPFIL_INDEXES.ATTRIBUTE_SET is 'Name of the attribute set used for this index'
/

comment on column ADM_EXPFIL_INDEXES.EXPRESSION_TABLE is 'The table storing the expression set corresponding to this index'
/

comment on column ADM_EXPFIL_INDEXES.EXPRESSION_COLUMN is 'The column storing the expression set corresponding to this index'
/

comment on column ADM_EXPFIL_INDEXES.STATUS is 'The current status of the index : VALID, FAILED [IMP], INPROGRESS'
/

