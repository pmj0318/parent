create function arrhasvalue(ioper exf$indexoper, val varchar2)
  return number is
  retval number := 0;
begin
  select count(*) into retval from table (cast(ioper as exf$indexoper))
    where upper(column_value) = upper(val);
  return retval;
end;
/

