create view USER_EXPFIL_ATTRIBUTES as
select atsname, attrname, attrtype,
        decode (bitand(attrprop, 16), 16, attrtptab, null), attrdefvl,
        decode (bitand(attrprop, 32), 32, attrtxtprf, 'N/A')
 from exf$attrlist where  atsowner = (select user from dual)
  order by atsowner, atsname, elattrid
/

comment on table USER_EXPFIL_ATTRIBUTES is 'List of all the elementary attributes in the current schema'
/

comment on column USER_EXPFIL_ATTRIBUTES.ATTRIBUTE_SET_NAME is 'Name of the attribute set this attribute belongs to'
/

comment on column USER_EXPFIL_ATTRIBUTES.ATTRIBUTE is 'Name of the attribute'
/

comment on column USER_EXPFIL_ATTRIBUTES.DATA_TYPE is 'Datatype of the attribute'
/

comment on column USER_EXPFIL_ATTRIBUTES.ASSOCIATED_TABLE is 'Table associated with table alias attribute'
/

comment on column USER_EXPFIL_ATTRIBUTES.DEFAULT_VALUE is 'String representation of the default value for the attribute'
/

comment on column USER_EXPFIL_ATTRIBUTES.TEXT_PREFERENCES is 'Preferences for an attribute configured for text predicates'
/

