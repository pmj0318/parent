create TYPE namelist IS TABLE OF VARCHAR2(110);
/

