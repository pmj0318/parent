create view ALL_RLMGR_COMPRCLS_PROPERTIES as
select crs.rset_owner, crs.rset_name, crs.prim_attr, crs.prim_asetnm,
      decode(bitand(pem.prim_evttflgs, 1), 1, 'YES', 'NO'),
      decode(bitand(pem.prim_evttflgs, 32),32, 'EXCLUSIVE','SHARED'),
      decode(pem.talstabonr, null, null,
           '"'||pem.talstabonr||'"."'||pem.talstabnm||'"'),
     pem.prim_evdurcls,
     decode(bitand(pem.prim_evttflgs, 128), 128, 'YES','NO'),
     pem.collcttab, pem.grpbyattrs
 from rlm$rsprimevents crs, rlm$primevttypemap pem
   where (crs.rset_owner = sys_context('USERENV', 'CURRENT_USER') or
       ((crs.rset_owner, crs.rset_name) IN
       (select rsp.rset_owner, rsp.rset_name from rlm$rulesetprivs rsp
          where prv_grantee = sys_context('USERENV', 'CURRENT_USER'))) or
       exists (select 1 from user_role_privs where granted_role = 'DBA'))
       and crs.rset_owner = pem.rset_owner and crs.rset_name = pem.rset_name
       and crs.prim_asetnm = pem.prim_evntst
/

comment on table ALL_RLMGR_COMPRCLS_PROPERTIES is 'List of primitive events configured for a rule class and their properties'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.RULE_CLASS_OWNER is 'Owner of the rule class'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.RULE_CLASS_NAME is 'Name of the rule class configured for composite rules'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.PRIM_EVENT is 'Name of the primitive event in the composite event'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.PRIM_EVENT_STRUCT is 'Name of the primitive event structure (object type)'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.HAS_CRTTIME_ATTR is 'YES if the primitive event structure has the RLM$CRTTIME attribute'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.CONSUMPTION is 'Consumption policy for the primitive event: EXCLUSIVE/SHARED'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.TABLE_ALIAS_OF is 'Table name for the a table alias primitive event'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.DURATION is 'Duration policy for the primitive event'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.COLLECTION_ENB is 'Is the primitive event enabled for collections?'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.COLLECTION_TAB_NAME is 'Internal table storing the event collection information'
/

comment on column ALL_RLMGR_COMPRCLS_PROPERTIES.GROUPBY_ATTRIBUTES is 'Event attributes that may be used for GROUPBY clauses'
/

