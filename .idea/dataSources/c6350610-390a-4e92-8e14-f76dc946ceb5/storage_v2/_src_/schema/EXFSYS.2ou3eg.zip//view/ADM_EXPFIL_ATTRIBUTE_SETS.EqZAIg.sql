create view ADM_EXPFIL_ATTRIBUTE_SETS as
select atsowner, atsname from exf$attrset
/

comment on table ADM_EXPFIL_ATTRIBUTE_SETS is 'List of all the attribute sets in the current instance'
/

comment on column ADM_EXPFIL_ATTRIBUTE_SETS.OWNER is 'Owner of the attribute set'
/

comment on column ADM_EXPFIL_ATTRIBUTE_SETS.ATTRIBUTE_SET_NAME is 'Name of the attribute set'
/

