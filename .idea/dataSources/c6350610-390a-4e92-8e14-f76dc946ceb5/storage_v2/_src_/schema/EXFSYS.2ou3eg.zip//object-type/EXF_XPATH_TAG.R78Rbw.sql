create type exf$xpath_tag as object (
  tag_name     VARCHAR2(350), -- <ns:name> / <ns:name>@<name2>
  tag_indexed  VARCHAR2(5),  -- default 'TRUE' for positional filter and
                             -- 'FALSE' for value filter
  tag_type     VARCHAR2(30), -- Xschema types mapped to DB types
                             -- null value implies a positional filter for
                             -- tag. Otherwise a value filter.
  constructor function exf$xpath_tag(tag_name varchar2)
    return self as result
);
/

