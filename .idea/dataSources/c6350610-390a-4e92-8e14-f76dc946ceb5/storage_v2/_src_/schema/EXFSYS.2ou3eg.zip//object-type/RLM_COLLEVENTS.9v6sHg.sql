create type        rlm$collevents is table of exfsys.rlm$collevent;
/

