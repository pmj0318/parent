create view ALL_EXPFIL_PREDTAB_ATTRIBUTES as
select io.idxowner, io.idxName, pc.ptattrid, pc.ptattralias,
  pc.ptattrsexp, pc.ptattrtype,
  decode (bitand(pc.ptattrprop, 1), 1, 'YES','NO'),
  decode (bitand(pc.ptattrprop, 2), 2, 'YES','NO'), varray2str(ptattroper),
  pc.xmltattr, decode(bitand(ptattrprop, 8), 8, 'XML ELEMENT',
              decode(bitand(ptattrprop, 16), 16, 'XML ATTRIBUTE', null)),
  decode(bitand(ptattrprop, 32), 32, 'POSITIONAL',
         decode(bitand(ptattrprop, 128), 128, 'CHAR VALUE',
           decode(bitand(ptattrprop, 256), 256, 'INT VALUE',
             decode(bitand(ptattrprop, 512), 512, 'DATE VALUE', null))))
  from exf$predattrmap pc, exf$idxsecobj io, all_indexes ai
  where io.idxobj# = pc.ptidxobj# and io.idxowner = ai.owner
  and io.idxname = ai.index_name
/

comment on table ALL_EXPFIL_PREDTAB_ATTRIBUTES is 'List of all the predicate table attributes'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.OWNER is 'Owner of the index'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.INDEX_NAME is 'Name of the index associated with the predicate table'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.ATTRIBUTE_ID is 'Identifier for the predicate table attribute'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.ATTRIBUTE_ALIAS is 'Alias for the predicate table attribute'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.SUBEXPRESSION is 'Sub-expression representing the complex or elementary attribute'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.DATA_TYPE is 'Resulting datatype of the sub-expression'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.STORED is 'Field to indicate if the attribute is stored in the predicate table'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.INDEXED is 'Field to indicate if the attribute is indexed in the predicate table'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.OPERATOR_LIST is 'List of common operators for the attribute'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.XMLTYPE_ATTR is 'The XMLType attribute for which the current XPath attribute is defined'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.XPTAG_TYPE is 'Type of the Tag - XML ELEMENT or XML ATTRIBUTE'
/

comment on column ALL_EXPFIL_PREDTAB_ATTRIBUTES.XPFILTER_TYPE is 'Type of filter for the XPath tag - POSITIONAL/ [CHAR|INT|DATE] VALUE '
/

