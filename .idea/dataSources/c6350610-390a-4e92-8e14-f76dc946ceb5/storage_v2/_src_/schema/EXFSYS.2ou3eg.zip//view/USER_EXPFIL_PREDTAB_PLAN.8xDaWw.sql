create view USER_EXPFIL_PREDTAB_PLAN as
select i.idxname INDEX_NAME, p."STATEMENT_ID",p."PLAN_ID",p."TIMESTAMP",p."REMARKS",p."OPERATION",p."OPTIONS",p."OBJECT_NODE",p."OBJECT_OWNER",p."OBJECT_NAME",p."OBJECT_ALIAS",p."OBJECT_INSTANCE",p."OBJECT_TYPE",p."OPTIMIZER",p."SEARCH_COLUMNS",p."ID",p."PARENT_ID",p."DEPTH",p."POSITION",p."COST",p."CARDINALITY",p."BYTES",p."OTHER_TAG",p."PARTITION_START",p."PARTITION_STOP",p."PARTITION_ID",p."OTHER",p."DISTRIBUTION",p."CPU_COST",p."IO_COST",p."TEMP_SPACE",p."ACCESS_PREDICATES",p."FILTER_PREDICATES",p."PROJECTION",p."TIME",p."QBLOCK_NAME",p."OTHER_XML"
 from exf$plan_table p, exf$idxsecobj i
 where p.statement_id = i.idxobj# and i.idxowner =
        (select user from dual)
/

