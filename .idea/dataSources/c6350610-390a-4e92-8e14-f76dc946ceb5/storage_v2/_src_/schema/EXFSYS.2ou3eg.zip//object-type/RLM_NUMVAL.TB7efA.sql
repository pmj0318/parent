create type        rlm$numval is table of number;
/

