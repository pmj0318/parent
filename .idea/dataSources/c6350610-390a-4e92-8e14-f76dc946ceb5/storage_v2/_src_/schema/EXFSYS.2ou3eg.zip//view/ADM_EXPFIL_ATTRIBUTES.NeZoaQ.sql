create view ADM_EXPFIL_ATTRIBUTES as
  ( select atsowner, atsname, attrname,
         attrtype, 'YES', 'NO',
        'NO', 'NO', decode (bitand(attrprop, 16), 16, 'YES', 'NO'),
         null, null, attrtptab, attrdefvl
   from exf$attrlist eal where attrname not in (select attrsexp from
    exf$defidxparam dip where eal.atsowner = dip.atsowner and
    eal.atsname = dip.atsname)
  UNION ALL
  select atsowner, atsname, attrsexp,
         attrtype, decode (bitand(attrprop, 1), 1, 'YES','NO'),
                              decode (bitand(attrprop, 1), 1, 'NO','YES'),
         'YES', decode (bitand(attrprop, 8), 8, 'YES','NO'), 'NO',
         varray2str(attroper), xmltattr, null, null
  from exf$defidxparam
  where bitand(attrprop, 4) = 4
)
/

comment on table ADM_EXPFIL_ATTRIBUTES is 'List of all the attributes in the current instance'
/

comment on column ADM_EXPFIL_ATTRIBUTES.OWNER is 'Owner of the attribute set'
/

comment on column ADM_EXPFIL_ATTRIBUTES.ATTRIBUTE_SET_NAME is 'Name of the attribute set this attribute belongs to'
/

comment on column ADM_EXPFIL_ATTRIBUTES.ATTRIBUTE is 'Name of the attribute'
/

comment on column ADM_EXPFIL_ATTRIBUTES.DATA_TYPE is 'Datatype of the attribute'
/

comment on column ADM_EXPFIL_ATTRIBUTES.ELEMENTARY is 'Field to indicate if the attribute is elementary'
/

comment on column ADM_EXPFIL_ATTRIBUTES.COMPLEX is 'Field to indicate if the attribute is complex'
/

comment on column ADM_EXPFIL_ATTRIBUTES.STORED is 'Field to indicate if the attribute is stored in the predicate table'
/

comment on column ADM_EXPFIL_ATTRIBUTES.INDEXED is 'Field to indicate if the attribute is indexed in the predicate table'
/

comment on column ADM_EXPFIL_ATTRIBUTES.TABLE_ALIAS is 'Field to indicate if the elementary attribute is a table alias'
/

comment on column ADM_EXPFIL_ATTRIBUTES.OPERATOR_LIST is 'List of common operators for the attribute'
/

comment on column ADM_EXPFIL_ATTRIBUTES.XMLTYPE_ATTR is 'The XMLType attribute for which the current XPath attribute is defined'
/

comment on column ADM_EXPFIL_ATTRIBUTES.ASSOCIATED_TABLE is 'Table associated with the embedded ADT / table aliases'
/

comment on column ADM_EXPFIL_ATTRIBUTES.DEFAULT_VALUE is 'String representation of the default value for the attribute'
/

