create type bsln_metric_t as object
  (metric_id number
  ,status    varchar2(16)
  );
/

