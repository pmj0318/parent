create type bsln_statistics_set as table of bsln_statistics_t;
/

