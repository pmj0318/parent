create type bsln_observation_set as table of bsln_observation_t;
/

