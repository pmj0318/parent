create TYPE sdo_numtab AS TABLE OF NUMBER;
/

