create view GEODETIC_SRIDS as
select srid from MDSYS.CS_SRS where WKTEXT like 'GEOGCS%'
/

