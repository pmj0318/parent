create view USER_SDO_GEOR_SYSDATA as
SELECT TABLE_NAME, COLUMN_NAME,METADATA_COLUMN_NAME,
              RDT_TABLE_NAME,RASTER_ID,OTHER_TABLE_NAMES
FROM ALL_SDO_GEOR_SYSDATA
WHERE owner = sys_context('userenv', 'SESSION_USER')
/

create trigger SDO_GEOR_TRIG_INS1
  instead of insert
  on USER_SDO_GEOR_SYSDATA
  for each row
-- missing source code
/

create trigger SDO_GEOR_TRIG_DEL1
  instead of delete
  on USER_SDO_GEOR_SYSDATA
  for each row
-- missing source code
/

create trigger SDO_GEOR_TRIG_UPD1
  instead of update
  on USER_SDO_GEOR_SYSDATA
  for each row
-- missing source code
/

