create TYPE SDO_RANGE_ARRAY
                                                                       AS VARRAY(1048576) OF SDO_RANGE
/

