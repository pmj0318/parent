create TYPE SDO_NUMBER_ARRAY
                                                                       AS VARRAY(1048576) OF NUMBER
/

