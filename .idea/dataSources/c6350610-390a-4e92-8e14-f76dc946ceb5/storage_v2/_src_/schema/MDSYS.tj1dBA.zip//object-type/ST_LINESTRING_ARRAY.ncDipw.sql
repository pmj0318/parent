create TYPE ST_LINESTRING_ARRAY
                                       AS VARRAY(1048576) OF ST_LINESTRING
/

