create type       WfscomplexType as object ( ns varchar2(30), name varchar2(30))
/

