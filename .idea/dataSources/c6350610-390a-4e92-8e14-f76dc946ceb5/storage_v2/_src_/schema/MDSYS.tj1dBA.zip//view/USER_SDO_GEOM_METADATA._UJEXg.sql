create view USER_SDO_GEOM_METADATA as
SELECT SDO_TABLE_NAME TABLE_NAME,
       SDO_COLUMN_NAME COLUMN_NAME,
       SDO_DIMINFO DIMINFO,
       SDO_SRID SRID
FROM SDO_GEOM_METADATA_TABLE
WHERE  sdo_owner = sys_context('userenv', 'CURRENT_SCHEMA')
/

create trigger SDO_GEOM_TRIG_INS1
  instead of insert
  on USER_SDO_GEOM_METADATA
  for each row
-- missing source code
/

create trigger SDO_GEOM_TRIG_DEL1
  instead of delete
  on USER_SDO_GEOM_METADATA
  for each row
-- missing source code
/

create trigger SDO_GEOM_TRIG_UPD1
  instead of update
  on USER_SDO_GEOM_METADATA
  for each row
-- missing source code
/

