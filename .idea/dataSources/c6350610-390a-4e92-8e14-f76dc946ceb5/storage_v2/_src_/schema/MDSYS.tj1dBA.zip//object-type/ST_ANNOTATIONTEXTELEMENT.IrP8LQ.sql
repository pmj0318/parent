create TYPE ST_ANNOTATIONTEXTELEMENT
                                                                                   AS OBJECT (
      privateValue  VARCHAR2(4000),
      privateLocation SDO_GEOMETRY,
      privateLeaderLine SDO_GEOMETRY,
      privateTextAttributes VARCHAR2(4000),
      MEMBER FUNCTION Value Return VARCHAR2,
    MEMBER FUNCTION Value(Value VARCHAR2)  RETURN ST_ANNOTATIONTEXTELEMENT,
    MEMBER FUNCTION Location Return SDO_GEOMETRY,
    MEMBER FUNCTION Location(Location SDO_GEOMETRY)
                  RETURN ST_ANNOTATIONTEXTELEMENT,
    MEMBER FUNCTION LeaderLine Return SDO_GEOMETRY,
    MEMBER FUNCTION LeaderLine(LeaderLine SDO_GEOMETRY)
         RETURN ST_ANNOTATIONTEXTELEMENT,
    MEMBER FUNCTION TextAttributes Return VARCHAR2,
    MEMBER FUNCTION TextAttributes(TextAttributes VARCHAR2)
       RETURN ST_ANNOTATIONTEXTELEMENT)
/

