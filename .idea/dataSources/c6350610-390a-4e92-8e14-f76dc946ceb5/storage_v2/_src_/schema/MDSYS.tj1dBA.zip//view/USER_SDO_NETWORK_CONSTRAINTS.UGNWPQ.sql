create view USER_SDO_NETWORK_CONSTRAINTS as
SELECT  constraint, description, class_name, class
    FROM  sdo_network_constraints
    WHERE sdo_owner = sys_context('USERENV', 'CURRENT_SCHEMA')
/

create trigger SDO_NETWORK_CONS_INS_TRIG
  instead of insert
  on USER_SDO_NETWORK_CONSTRAINTS
  for each row
-- missing source code
/

create trigger SDO_NETWORK_CONS_DEL_TRIG
  instead of delete
  on USER_SDO_NETWORK_CONSTRAINTS
  for each row
-- missing source code
/

create trigger SDO_NETWORK_CONS_UPD_TRIG
  instead of update
  on USER_SDO_NETWORK_CONSTRAINTS
  for each row
-- missing source code
/

