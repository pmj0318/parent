create TYPE sdo_stattab AS TABLE OF sdo_stat;
/

