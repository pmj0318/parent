create trigger SDO_NETWORK_TIME_INS_TRIG
  instead of insert
  on USER_SDO_NETWORK_TIMESTAMPS
  for each row
DECLARE
 user_name         VARCHAR2(32);
BEGIN

  EXECUTE IMMEDIATE 'SELECT user FROM dual' INTO user_name;

  INSERT INTO sdo_network_timestamps(
     owner, network, table_name, last_dml_time)
  VALUES(NLS_UPPER(user_name),:n.network,:n.table_name, :n.last_dml_time);

EXCEPTION WHEN OTHERS THEN RAISE;
END;
/

