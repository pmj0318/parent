create trigger SDO_GEOM_TRIG_UPD1
  instead of update
  on USER_SDO_GEOM_METADATA
  for each row
declare
 tname varchar2(32);
 stmt  varchar2(2048);
 vcount INTEGER;
BEGIN

  EXECUTE IMMEDIATE
  'SELECT user FROM dual' into tname;

    UPDATE sdo_geom_metadata_table
    SET (SDO_TABLE_NAME, SDO_COLUMN_NAME, SDO_DIMINFO, SDO_SRID)  =
     (SELECT upper(:n.table_name), upper(:n.column_name), :n.diminfo,
      :n.srid  FROM DUAL)
    WHERE SDO_OWNER = tname
      AND SDO_TABLE_NAME = upper(:old.table_name)
      AND SDO_COLUMN_NAME = upper(:old.column_name);
END;
/

