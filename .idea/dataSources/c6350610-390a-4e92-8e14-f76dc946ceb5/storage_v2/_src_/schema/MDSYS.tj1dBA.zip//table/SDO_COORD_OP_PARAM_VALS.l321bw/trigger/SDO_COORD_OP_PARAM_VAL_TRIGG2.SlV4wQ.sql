create trigger SDO_COORD_OP_PARAM_VAL_TRIGG2
  after insert or update or delete
  on SDO_COORD_OP_PARAM_VALS
BEGIN
  update
    sdo_cs_srs
  set
    wktext = MDSYS.sdo_cs.internal_det_srid_wkt(srid),
    wktext3d = mdsys.sdo_cs.get_3d_wkt(srid)
  where
    wktext = 'Getting updated';
end;
/

