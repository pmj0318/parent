create trigger SDO_NETWORK_TIME_DEL_TRIG
  instead of delete
  on USER_SDO_NETWORK_TIMESTAMPS
  for each row
DECLARE
  user_name    VARCHAR2(256);
BEGIN

  EXECUTE IMMEDIATE 'SELECT USER FROM DUAL' INTO user_name;

  DELETE
    FROM  sdo_network_timestamps
    WHERE owner = NLS_UPPER(user_name)
      AND network = :o.network
      AND table_name = :o.table_name;
END;
/

