create TYPE SDO_GEOR_GCP_COLLECTION
                                                                       AS VARRAY(1048576) OF SDO_GEOR_GCP
/

