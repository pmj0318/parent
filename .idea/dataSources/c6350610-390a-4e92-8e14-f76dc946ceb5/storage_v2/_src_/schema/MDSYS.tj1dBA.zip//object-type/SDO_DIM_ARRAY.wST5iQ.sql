create TYPE SDO_DIM_ARRAY
                                                                       AS VARRAY(4) OF SDO_DIM_ELEMENT
/

