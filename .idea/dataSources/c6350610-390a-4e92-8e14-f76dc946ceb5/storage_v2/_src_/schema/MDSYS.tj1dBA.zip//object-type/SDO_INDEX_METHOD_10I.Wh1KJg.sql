create type sdo_index_method_10i
                                       AUTHID current_user  AS OBJECT
(
  scan_ctx raw(4),
  STATIC function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
         return number,
  STATIC function ODCIIndexCreate (ia sys.odciindexinfo, parms varchar2,
                                   env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexDrop  (ia sys.odciindexinfo, env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexTruncate (ia sys.odciindexinfo, env sys.ODCIEnv)
          return number,
  STATIC function ODCIIndexCoalescePartition(ia sys.odciindexinfo,
                                             env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexExchangePartition(ia sys.odciindexinfo,
                                             ia1 sys.odciindexinfo,
                                             env sys.ODCIEnv)
          return number,
  STATIC function ODCIIndexMergePartition(ia sys.odciindexinfo,
                                          part_name1 sys.odcipartinfo,
                                          part_name2 sys.odcipartinfo,
                                          params varchar2,
                                          env sys.ODCIEnv)
          return number,
  STATIC function ODCIIndexSplitPartition(ia sys.odciindexinfo,
                                          part_name1 sys.odcipartinfo,
                                          part_name2 sys.odcipartinfo,
                                          params varchar2,
                                          env sys.ODCIEnv)
          return number,
  STATIC function ODCIIndexInsert (ia sys.odciindexinfo, rid varchar2,
                                   newval mdsys.sdo_geometry,
                                   env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexDelete (ia sys.odciindexinfo, rid varchar2,
                                   oldval mdsys.sdo_geometry,
                                   env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexUpdate (ia sys.odciindexinfo, rid varchar2,
                                   oldval mdsys.sdo_geometry,
                                   newval mdsys.sdo_geometry,
                                   env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexAlter (ia sys.odciindexinfo,
                                  params IN OUT varchar2,
                                  alter_option number,
                                  env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i,
                                  ia sys.odciindexinfo,
                                  op sys.OdciPredInfo,
                                  qi sys.OdciQueryInfo,
                                  strt varchar2, stop varchar2,
                                  win_obj mdsys.sdo_geometry,
                                  params varchar2,
                                  env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i,
                                  ia sys.odciindexinfo,
                                  op sys.OdciPredInfo,
                                  qi sys.OdciQueryInfo,
                                  strt varchar2, stop varchar2,
                                  win_obj mdsys.sdo_geometry, rid ROWID,
                                  params varchar2,
                                  idx_tab1 varchar2, idx_tab2 varchar2,
                                  sdo_level number, sdo_ntiles number,
                                  win_ndim number,
                                  env sys.ODCIEnv)
         return number,
  STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i,
                                  ia sys.odciindexinfo,
                                  op sys.OdciPredInfo,
                                  qi sys.OdciQueryInfo,
                                  strt varchar2, stop varchar2,
                                  win_obj mdsys.sdo_geometry,
                                  env sys.ODCIEnv)
         return number,
  member function ODCIIndexFetch (nrows number,
                                  rids OUT sys.odciridlist,
                                  env sys.ODCIEnv)
        return number
        IS LANGUAGE C
        name "md_idx_fetch"
        library ORDMD_IDX_LIBS
        with context
        parameters (
           context,
           self,
           self INDICATOR STRUCT,
           nrows,
           nrows INDICATOR,
           rids,
           rids INDICATOR,
           env,
           env INDICATOR STRUCT,
           return OCINumber
      ),
  member function ODCIIndexClose (env sys.ODCIEnv)
   return number
   IS LANGUAGE C
   name "md_idx_close"
   library ORDMD_IDX_LIBS
   with context
   parameters (
     context,
     self,
     self INDICATOR STRUCT,
     env,
     env INDICATOR STRUCT,
     return OCINumber
   ),
  STATIC function ODCIIndexRewrite(ia1 sys.ODCIIndexInfo,
                                   ia2 sys.ODCIIndexInfo,
                                   cor1 VARCHAR2, cor2 VARCHAR2,
                                   op sys.ODCIPredInfo, qi sys.ODCIQueryInfo,
                                   strt VARCHAR2, stop VARCHAR2,
                                   params varchar2, rstr OUT varchar2,
                                   env sys.ODCIEnv)
      return number,
  STATIC function ODCIIndexGetMetadata(ia sys.odciindexinfo,
                                       expversion VARCHAR2,
                                       newblock OUT PLS_INTEGER,
                                     env sys.ODCIEnv)
      return varchar2,
   static function ODCIIndexUtilGetTableNames(ia        IN  sys.odciindexinfo,
                                              read_only IN  PLS_INTEGER,
                                              version   IN  varchar2,
                                              context   OUT PLS_INTEGER)
            return boolean,
   static procedure ODCIIndexUtilCleanup(context IN PLS_INTEGER),

 STATIC function ODCIIndexInsert (ia sys.odciindexinfo, rid varchar2,
                                   newval mdsys.sdo_topo_geometry,
                                   env sys.ODCIEnv)
         return number,
 STATIC function ODCIIndexDelete (ia sys.odciindexinfo, rid varchar2,
                                   oldval mdsys.sdo_topo_geometry,
                                   env sys.ODCIEnv)
         return number,
 STATIC function ODCIIndexUpdate (ia sys.odciindexinfo, rid varchar2,
                                   oldval mdsys.sdo_topo_geometry,
                                   newval mdsys.sdo_topo_geometry,
                                   env sys.ODCIEnv)
         return number,
 STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i,
                                  ia sys.odciindexinfo,
                                  op sys.OdciPredInfo,
                                  qi sys.OdciQueryInfo,
                                  strt varchar2, stop varchar2,
                                  win_obj mdsys.sdo_topo_geometry,
                                  params varchar2,
                                  env sys.ODCIEnv)
         return number,
 STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i,
                                  ia sys.odciindexinfo,
                                  op sys.OdciPredInfo,
                                  qi sys.OdciQueryInfo,
                                  strt varchar2, stop varchar2,
                                  win_obj mdsys.sdo_topo_geometry,
                                  env sys.ODCIEnv)
         return number,
 STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i,
                                  ia sys.odciindexinfo,
                                  op sys.OdciPredInfo,
                                  qi sys.OdciQueryInfo,
                                  strt varchar2, stop varchar2,
                                  win_obj mdsys.sdo_topo_object_array,
                                  env sys.ODCIEnv)
   RETURN number )
 alter type sdo_index_method_10i  add STATIC FUNCTION execute_index_ptn_drop(ia in SYS.ODCIIndexInfo)  RETURN number
 alter type sdo_index_method_10i  add STATIC FUNCTION index_update (ia sys.odciindexinfo, rid varchar2,  oldval mdsys.sdo_geometry, newval mdsys.sdo_geometry,  env sys.ODCIEnv) RETURN NUMBER
 alter type sdo_index_method_10i  add STATIC FUNCTION insert_delete(ia sys.odciindexinfo, rid varchar2, val mdsys.sdo_geometry, upd_type varchar2, env sys.ODCIEnv)  RETURN number
  alter type sdo_index_method_10i  add STATIC function ODCIIndexInsert (ia sys.odciindexinfo,  rid varchar2, newval mdsys.st_geometry, env sys.ODCIEnv)  return number
  alter type sdo_index_method_10i  add STATIC function ODCIIndexDelete (ia sys.odciindexinfo,   rid varchar2, oldval mdsys.st_geometry, env sys.ODCIEnv)      return number
  alter type sdo_index_method_10i  add STATIC function ODCIIndexUpdate (ia sys.odciindexinfo,   rid varchar2, oldval mdsys.st_geometry, newval mdsys.st_geometry,  env sys.ODCIEnv)  return number
  alter type sdo_index_method_10i  add STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i, ia sys.odciindexinfo,op sys.OdciPredInfo, qi sys.OdciQueryInfo,  strt varchar2, stop varchar2,win_obj mdsys.st_geometry,  env sys.ODCIEnv)  return number
  alter type sdo_index_method_10i  add STATIC function ODCIIndexStart (SCTX IN OUT sdo_index_method_10i, ia sys.odciindexinfo,op sys.OdciPredInfo, qi sys.OdciQueryInfo,  strt varchar2, stop varchar2,win_obj mdsys.st_geometry,  params varchar2, env sys.ODCIEnv)  return number
  alter type sdo_index_method_10i  add STATIC function ODCIIndexRewrite(ia1 sys.ODCIIndexInfo,  ia2 sys.ODCIIndexInfo, cor1 VARCHAR2, cor2 VARCHAR2,  op sys.ODCIPredInfo, qi sys.ODCIQueryInfo, strt VARCHAR2,  stop VARCHAR2, rstr OUT varchar2, env sys.ODCIEnv) return number
/

