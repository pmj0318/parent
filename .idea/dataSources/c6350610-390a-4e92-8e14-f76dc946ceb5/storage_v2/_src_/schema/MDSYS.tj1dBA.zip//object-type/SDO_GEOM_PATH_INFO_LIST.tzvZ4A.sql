create type       sdo_geom_path_info_list as table of mdsys.sdo_geom_path_info_elem
/

