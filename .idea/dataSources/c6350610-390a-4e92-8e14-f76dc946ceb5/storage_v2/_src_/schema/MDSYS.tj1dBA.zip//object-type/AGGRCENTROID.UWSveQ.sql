create type AggrCentroid AUTHID current_user as Object
(
  context mdsys.SDOAggr,
  static function odciaggregateinitialize(sctx OUT AggrCentroid) return number,
  member function odciaggregateiterate(self IN OUT AggrCentroid,
               			       geom IN mdsys.SDOAggrType) return number,
  member function odciaggregateterminate(self IN AggrCentroid,
                                         returnValue OUT mdsys.sdo_geometry,
                                          flags IN number)
                     return number,
  member function odciaggregatemerge(self   IN OUT AggrCentroid,
                    		     valueB IN  AggrCentroid) return number);
/

