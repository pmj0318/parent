create view CURRENTSESSIONTOKENMAP$ as
select sessionId , tokenId from MDSYS.CurrentSessionTokenMap_t$ where sessionId in (select dbms_session.unique_session_id from dual)
/

