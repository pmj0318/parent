create type       RowPointerList is table of varchar2(4000)
/

