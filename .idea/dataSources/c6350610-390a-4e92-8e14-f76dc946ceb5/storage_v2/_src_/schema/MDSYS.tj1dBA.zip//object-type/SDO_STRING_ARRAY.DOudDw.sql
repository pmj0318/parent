create TYPE SDO_STRING_ARRAY
                                                                       AS VARRAY(1048576) OF VARCHAR2(32)
/

