create type       StringList is varray(1000000) of varchar2(4000)
/

